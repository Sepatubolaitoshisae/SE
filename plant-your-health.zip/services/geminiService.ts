
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// As per instructions, process.env.API_KEY is assumed to be available
// and is used directly for initializing the GoogleGenAI client.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = 'gemini-2.5-flash-preview-04-17';

export const getReflectionFromGemini = async (journalText: string): Promise<string> => {
  // A runtime check can provide more specific feedback if the API key is missing.
  if (!process.env.API_KEY) {
    console.error("Gemini API key (process.env.API_KEY) is not set. API calls will fail.");
    throw new Error("API_KEY_MISSING: Gemini API key is not configured in the environment. Please set the API_KEY environment variable.");
  }
  
  const prompt = `You are a gentle and insightful journaling assistant. Read the following journal entry and provide a brief, positive, and encouraging reflection on it. Focus on identifying strengths, positive aspects, or offering a compassionate perspective. Keep the reflection to 2-3 sentences. Journal Entry: "${journalText}"`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });
    
    // Directly access the .text property as per guidelines
    const reflectionText = response.text;

    if (typeof reflectionText !== 'string' || reflectionText.trim() === '') {
        console.warn("Gemini API returned an empty or non-string reflection for prompt:", prompt);
        throw new Error("Received empty or invalid reflection from Gemini API. The AI might need more context or the entry was too short.");
    }
    return reflectionText;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes("API key not valid") || 
            error.message.includes("API_KEY_INVALID") || 
            error.message.includes("permission to access project")) {
             throw new Error("Invalid or misconfigured Gemini API Key. Please check your environment configuration and ensure the key has correct permissions.");
        }
         if (error.message.includes("Quota exceeded")) {
            throw new Error("Gemini API quota exceeded. Please check your usage limits or try again later.");
        }
        throw new Error(`Failed to get reflection from Gemini: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching reflection from Gemini.");
  }
};
