
import React from 'react';
import { useAuth } from './contexts/AuthContext';
import AuthForm from './components/Auth/AuthForm';
import HomeScreen from './components/Dashboard/HomeScreen';
import LoadingSpinner from './components/Common/LoadingSpinner';

const App: React.FC = () => {
  const { currentUser, loading: authLoading, appUser } = useAuth();

  if (authLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-green-50">
        <LoadingSpinner message="Loading Plant Your Health..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-100 via-emerald-50 to-teal-100">
      {!currentUser ? <AuthForm /> : <HomeScreen />}
    </div>
  );
};

export default App;
