
import type { User as FirebaseUser } from 'firebase/auth';

export interface AppUser {
  uid: string;
  email: string | null;
  displayName?: string | null; // Added for personalization
  waterTarget: number; // in ml
  waterProgress: number; // in ml, daily
  treeHealth: number; // 0-100 scale
  lastLogin?: Date;
  createdAt?: Date;
}

export interface Reflection {
  originalText: string;
  reflectionText: string;
  timestamp: Date;
}

export interface AuthContextType {
  currentUser: FirebaseUser | null;
  appUser: AppUser | null; // Application-specific user data from Firestore
  loading: boolean;
  error: string | null;
  signUp: (email: string, password: string, displayName?: string) => Promise<void>;
  logIn: (email: string, password: string) => Promise<void>;
  logOut: () => Promise<void>;
  clearError: () => void;
}

export enum ApiStatus {
  IDLE = 'idle',
  LOADING = 'loading',
  SUCCESS = 'success',
  ERROR = 'error',
}
