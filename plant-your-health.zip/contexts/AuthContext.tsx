
import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { User as FirebaseUser } from 'firebase/auth';
import {
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { auth, db } from '../services/firebase';
import type { AppUser, AuthContextType } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null); // Renamed from 'error'

  const clearError = () => setAuthError(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const userRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(userRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setAppUser({
            ...data,
            uid: user.uid,
            lastLogin: data.lastLogin instanceof Timestamp ? data.lastLogin.toDate() : data.lastLogin,
            createdAt: data.createdAt instanceof Timestamp ? data.createdAt.toDate() : data.createdAt,
          } as AppUser);
        } else {
          console.warn("No Firestore document found for user:", user.uid);
          setAppUser(null); 
        }
      } else {
        setAppUser(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const signUp = async (email: string, password: string, displayNameInput?: string) => {
    setLoading(true);
    setAuthError(null);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      const nameToSet = displayNameInput || email.split('@')[0];
      // Ensure firebaseUser is not null before calling updateProfile
      if (firebaseUser) {
         await updateProfile(firebaseUser, { displayName: nameToSet });
      } else {
        // This case should ideally not happen if createUserWithEmailAndPassword succeeds
        // but it's good practice for type safety.
        throw new Error("User creation succeeded but user object is null.");
      }
      
      const newUser: AppUser = {
        uid: firebaseUser.uid,
        email: firebaseUser.email,
        displayName: nameToSet,
        waterTarget: 2000, 
        waterProgress: 0,
        treeHealth: 70, 
        createdAt: new Date(),
        lastLogin: new Date(),
      };
      await setDoc(doc(db, 'users', firebaseUser.uid), {
        ...newUser,
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp()
      });
      setAppUser(newUser); 
    } catch (err: any) {
      console.error("Sign up error:", err);
      setAuthError(err.message || 'Failed to sign up');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logIn = async (email: string, password: string) => {
    setLoading(true);
    setAuthError(null);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      console.error("Log in error:", err);
      setAuthError(err.message || 'Failed to log in');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logOut = async () => {
    setLoading(true);
    setAuthError(null);
    try {
      await signOut(auth);
    } catch (err: any) { // err is now properly scoped
      setAuthError(err.message || 'Failed to log out');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const value: AuthContextType = {
    currentUser,
    appUser,
    loading,
    error: authError, // Use the renamed state variable
    signUp,
    logIn,
    logOut,
    clearError,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
