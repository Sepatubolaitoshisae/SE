
import React from 'react';

interface LoadingSpinnerProps {
  message?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message }) => {
  return (
    <div className="flex flex-col justify-center items-center my-10 space-y-3">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-emerald-600"></div>
      {message && <p className="text-lg text-emerald-700 font-medium">{message}</p>}
    </div>
  );
};

export default LoadingSpinner;
