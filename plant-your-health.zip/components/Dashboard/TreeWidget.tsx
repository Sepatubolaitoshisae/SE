
import React from 'react';

interface TreeWidgetProps {
  health: number; // 0-100
}

const TreeWidget: React.FC<TreeWidgetProps> = ({ health }) => {
  let treeImage = '/assets/images/seedling.png'; // Default
  let statusMessage = "I'm just starting out!";

  if (health >= 70) {
    treeImage = '/assets/images/thriving_tree.png';
    statusMessage = "I'm feeling great and thriving!";
  } else if (health >= 30) {
    treeImage = '/assets/images/seedling.png'; // Or a medium tree
    statusMessage = "I'm growing, keep up the good work!";
  } else {
    treeImage = '/assets/images/withered_tree.png';
    statusMessage = "I need some care and attention...";
  }

  return (
    <div className="text-center p-4">
      <img 
        src={treeImage} 
        alt="Health Tree" 
        className="mx-auto mb-4 w-48 h-48 sm:w-64 sm:h-64 object-contain transition-all duration-500 ease-in-out" 
        aria-live="polite"
        aria-label={`Your tree is ${health >= 70 ? 'thriving' : health >=30 ? 'growing' : 'withered'}. Current health: ${health} percent.`}
      />
      <p className="text-lg text-emerald-600 italic" aria-hidden="true">{statusMessage}</p>
      <div className="w-full bg-gray-200 rounded-full h-2.5 mt-3">
        <div 
            className="bg-green-500 h-2.5 rounded-full transition-all duration-500 ease-out" 
            style={{ width: `${health}%` }}
            role="progressbar"
            aria-valuenow={health}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label={`Tree health: ${health}%`}
        ></div>
      </div>
       <p className="text-sm text-gray-500 mt-1">Health: {health}%</p>
    </div>
  );
};

export default TreeWidget;
