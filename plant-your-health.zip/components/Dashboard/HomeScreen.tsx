
import React, { useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import TreeWidget from './TreeWidget';
import WaterTracker from './WaterTracker';
import LoadingSpinner from '../Common/LoadingSpinner';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../services/firebase';

const HomeScreen: React.FC = () => {
  const { appUser, logOut, currentUser } = useAuth();

  useEffect(() => {
    // Update lastLogin timestamp when HomeScreen is mounted and user is available
    if (currentUser?.uid && appUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        updateDoc(userRef, { lastLogin: serverTimestamp() })
          .catch(err => console.error("Failed to update last login:", err));
    }
  }, [currentUser, appUser]);


  if (!appUser) {
    return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner message="Loading your garden..." /></div>;
  }

  const handleLogout = async () => {
    try {
      await logOut();
    } catch (error) {
      console.error("Logout failed", error);
      // Display error to user if needed
    }
  };

  return (
    <div className="min-h-screen flex flex-col p-4 sm:p-6 bg-gradient-to-br from-green-100 via-emerald-50 to-teal-100 selection:bg-emerald-200">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold text-emerald-800">
            Hello, {appUser.displayName || appUser.email?.split('@')[0]}!
          </h1>
          <p className="text-gray-600">Let's nurture your health today.</p>
        </div>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-150 shadow hover:shadow-md"
          aria-label="Log out"
        >
          Logout
        </button>
      </header>

      <main className="flex-grow grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white/80 backdrop-blur-md p-6 rounded-xl shadow-lg flex flex-col items-center justify-center">
          <h2 className="text-2xl font-semibold text-emerald-700 mb-6">Your Health Tree</h2>
          <TreeWidget health={appUser.treeHealth} />
        </div>

        <div className="lg:col-span-1 bg-white/80 backdrop-blur-md p-6 rounded-xl shadow-lg">
          <WaterTracker 
            currentProgress={appUser.waterProgress} 
            target={appUser.waterTarget} 
            userId={appUser.uid}
            currentTreeHealth={appUser.treeHealth}
          />
        </div>
      </main>
      
      <footer className="mt-12 text-center text-sm text-gray-500">
        <p>&copy; {new Date().getFullYear()} Plant Your Health. Grow a better you.</p>
         <p className="mt-1 text-xs px-4">
          Remember to set your Firebase environment variables. Tree images are placeholders.
        </p>
      </footer>
    </div>
  );
};

export default HomeScreen;
