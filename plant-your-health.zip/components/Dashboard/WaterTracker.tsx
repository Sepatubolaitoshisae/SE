
import React, { useState } from 'react';
import { doc, updateDoc, increment, runTransaction } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { AppUser } from '../../types'; // Assuming AppUser might be needed or for reference
import ErrorDisplay from '../Common/ErrorDisplay'; // For showing errors

interface WaterTrackerProps {
  currentProgress: number;
  target: number;
  userId: string;
  currentTreeHealth: number;
}

const WaterTracker: React.FC<WaterTrackerProps> = ({ currentProgress, target, userId, currentTreeHealth }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const percentage = target > 0 ? Math.min((currentProgress / target) * 100, 100) : 0;

  const handleLogWater = async (amount: number) => {
    setIsLoading(true);
    setError(null);
    const userRef = doc(db, 'users', userId);

    try {
      await runTransaction(db, async (transaction) => {
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) {
          throw new Error("User document does not exist!");
        }

        const currentData = userDoc.data() as AppUser;
        const newProgress = (currentData.waterProgress || 0) + amount;
        
        // Simple tree health logic: gain 2 health points per 250ml, cap at 100
        // Lose 1 if progress is still 0 after logging (to encourage first drink)
        let healthChange = 0;
        if (newProgress > currentData.waterProgress) { // Only if progress increased
             healthChange = Math.floor(amount / 125); // ~2 points per 250ml
        }
        
        const newTreeHealth = Math.min(Math.max(0, (currentData.treeHealth || 0) + healthChange), 100);

        transaction.update(userRef, { 
          waterProgress: newProgress,
          treeHealth: newTreeHealth
        });
      });
      // UI will update via AuthContext listener on AppUser
    } catch (err: any) {
      console.error("Failed to log water:", err);
      setError(err.message || "Could not log water. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const waterAmounts = [100, 250, 500]; // in ml

  return (
    <div className="p-4 space-y-4 rounded-lg">
      <h3 className="text-xl font-semibold text-emerald-700 mb-2">Daily Water Intake</h3>
      
      {error && <ErrorDisplay message={error} onDismiss={() => setError(null)} />}

      <div className="text-center mb-3">
        <span className="text-3xl font-bold text-emerald-600">{currentProgress}</span>
        <span className="text-lg text-gray-500"> / {target} ml</span>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-4">
        <div
          className="bg-blue-500 h-4 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${percentage}%` }}
          role="progressbar"
          aria-valuenow={currentProgress}
          aria-valuemin={0}
          aria-valuemax={target}
          aria-label={`Water intake: ${currentProgress} of ${target} ml`}
        ></div>
      </div>
      <p className="text-sm text-gray-500 text-right">{percentage.toFixed(0)}% complete</p>

      <div className="mt-4 space-y-2">
        <p className="text-md font-medium text-gray-700">Log Water:</p>
        <div className="flex flex-wrap gap-2 justify-center">
          {waterAmounts.map((amount) => (
            <button
              key={amount}
              onClick={() => handleLogWater(amount)}
              disabled={isLoading}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-150 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 disabled:bg-gray-300 shadow hover:shadow-md"
            >
              + {amount} ml
            </button>
          ))}
        </div>
      </div>
       {/* TODO: Add ability to set target */}
    </div>
  );
};

export default WaterTracker;
