
import React, { useState } from 'react';

interface JournalInputProps {
  onSubmit: (text: string) => void;
  isLoading: boolean;
}

const JournalInput: React.FC<JournalInputProps> = ({ onSubmit, isLoading }) => {
  const [entryText, setEntryText] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (entryText.trim() && !isLoading) {
      onSubmit(entryText.trim());
      // Optionally clear text: setEntryText(''); 
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full bg-white p-6 sm:p-8 rounded-xl shadow-xl space-y-6 transform transition-all hover:shadow-2xl">
      <h2 className="text-3xl font-bold text-center text-slate-800">What's on your mind?</h2>
      <div>
        <label htmlFor="journalEntry" className="sr-only">Journal Entry</label>
        <textarea
          id="journalEntry"
          value={entryText}
          onChange={(e) => setEntryText(e.target.value)}
          placeholder="Pour your thoughts here, like water flowing..."
          className="w-full h-48 p-4 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-600 transition-shadow duration-200 ease-in-out resize-y text-slate-700 placeholder-slate-400 text-base"
          disabled={isLoading}
        />
      </div>
      <button
        type="submit"
        disabled={isLoading || !entryText.trim()}
        className={`w-full text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 
                    ${isLoading || !entryText.trim()
                        ? 'bg-slate-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 focus:ring-sky-500 shadow-md hover:shadow-lg transform hover:-translate-y-0.5'}`}
      >
        {isLoading ? 'Reflecting...' : 'Get AI Reflection'}
      </button>
    </form>
  );
};

export default JournalInput;
