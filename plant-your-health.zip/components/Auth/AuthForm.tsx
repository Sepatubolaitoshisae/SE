
import React, { useState, FormEvent } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import ErrorDisplay from '../Common/ErrorDisplay';
import LoadingSpinner from '../Common/LoadingSpinner';

const AuthForm: React.FC = () => {
  const [isLogin, setIsLogin] = useState<boolean>(true);
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [displayName, setDisplayName] = useState<string>(''); // For registration
  const { signUp, logIn, loading, error, clearError } = useAuth();

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    clearError();
    try {
      if (isLogin) {
        await logIn(email, password);
      } else {
        await signUp(email, password, displayName);
      }
    } catch (err) {
      // Error is handled by AuthContext and displayed via `error` prop
      console.error("AuthForm submission error:", err);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-green-200 via-emerald-100 to-teal-200 p-4 selection:bg-emerald-200">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl space-y-6">
        <div className="text-center">
          <img src="/assets/images/app_logo.png" alt="Plant Your Health Logo" className="w-24 h-24 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-emerald-700">{isLogin ? 'Welcome Back!' : 'Create Account'}</h1>
          <p className="text-gray-600">{isLogin ? 'Log in to tend to your garden.' : 'Join us and grow your health!'}</p>
        </div>

        {error && <ErrorDisplay message={error} onDismiss={clearError} />}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {!isLogin && (
            <div>
              <label htmlFor="displayName" className="block text-sm font-medium text-gray-700">Display Name</label>
              <input
                id="displayName"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Your Name"
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
              />
            </div>
          )}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@example.com"
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              minLength={6}
              className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 disabled:bg-gray-400"
          >
            {loading ? <LoadingSpinner /> : (isLogin ? 'Log In' : 'Sign Up')}
          </button>
        </form>
        <div className="text-center">
          <button
            onClick={() => { setIsLogin(!isLogin); clearError(); }}
            className="font-medium text-emerald-600 hover:text-emerald-500"
          >
            {isLogin ? 'Need an account? Sign Up' : 'Already have an account? Log In'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthForm;
