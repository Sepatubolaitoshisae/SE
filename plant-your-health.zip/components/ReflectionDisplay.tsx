
import React from 'react';
import { Reflection } from '../types';

interface ReflectionDisplayProps {
  reflection: Reflection;
}

const ReflectionDisplay: React.FC<ReflectionDisplayProps> = ({ reflection }) => {
  return (
    <div className="w-full mt-10 bg-white p-6 sm:p-8 rounded-xl shadow-xl space-y-6 animate-fadeIn">
      <div className="border-b border-slate-200 pb-4">
        <h3 className="text-2xl font-semibold text-slate-800 mb-3">Your Entry:</h3>
        <p className="text-slate-700 text-base whitespace-pre-wrap bg-slate-50 p-4 rounded-lg border border-slate-200 shadow-inner">
          {reflection.originalText}
        </p>
      </div>
      <div>
        <h3 className="text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-sky-500 to-indigo-600 mb-3">
          Gemini's Insight:
        </h3>
        <p className="text-indigo-700 text-base whitespace-pre-wrap bg-gradient-to-br from-sky-50 to-indigo-100 p-4 rounded-lg border border-sky-200 shadow-inner">
          {reflection.reflectionText}
        </p>
        <p className="text-xs text-slate-500 mt-4 text-right">
          Reflected on: {reflection.timestamp.toLocaleDateString()} at {reflection.timestamp.toLocaleTimeString()}
        </p>
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default ReflectionDisplay;
